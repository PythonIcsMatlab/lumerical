%programmed by R.Borumandi
clc
clear
k2=1;
T=1;
syms E;
 syms Etemp
 Eed(41)=0;

for N=1:1:2
 i=1;
for t=0:1e-12:5e-12       
       
    for m=0:1:40
    if(1)
     omega=1;   
     cmn=-2*(m^2+N^2-1)/((m^2+N^2-1)^2-4*m^2*N^2);
     fun = @(t) besselj(1,omega*k2)*exp(-t.^2/T.^2);
     E=E+(-k2*omega/(2*3.14))*2*(1i^m)*(cmn)*integral(fun,0,.1 ); 
     disp(E);
     
     
    
    end
    end
    Etemp=E;
    i=i+1;
    Eed(i)=Etemp;
    t1=0:1:40;
    N1=1:1:41;
    Eout=1:1:41;
    plot3(t1,N1,Eed);hold on;
end

end
