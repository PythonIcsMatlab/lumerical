%programmed  by R.Borumandi with help my friends
clc
clear 
hold on
k1=-0.5*1i;
t1=sqrt(1-abs(k1)^2);
k2=0.1;							
t2=sqrt(1-abs(k2)^2);
R=16e-6;
neff=1.5;
P_out=(1/k1)*[-t1 1;-1 conj(t1)];
PM=(1/k2)*[-t2 1;-1 conj(t2)];
step =1e6;          
f =15.381:(1/step):15.393;  
L = length(f);     
for N=1:10:71
	c=1/(675*1.5e-3);
	X=c*exp(-(5e19)*(((f-15.387)*1e-7).^2));
	%subplot(2,2,1)
	%hold on
	plot(1e-7*f,X,'r')
	Q(1,1,(1:1:L))=0;
	Q(2,2,(1:1:L))=0;
	Q(1,2,(1:L))=exp(-1i*R*2*pi*pi*neff./(1e-7*f));
	Q(2,1,(1:L))=exp(1i*R*2*pi*pi*neff./(1e-7*f));
	for i=1:1:L
		M(:,:,i)=P_out*Q(:,:,i)*((PM*Q(:,:,i))^(N-1))*P_out;
		Tout(i)=M(2,1,i)-((M(1,1,i).*M(2,2,i))/M(1,2,i));
	end
	out=X.*Tout;
	%subplot(2,2,2)
	%hold on
	%plot(1e-7*f,real(out),'r')
	n = 2^nextpow2(L);
	Y = (ifft(out,n))/0.125;
	u=2;
	t = (1.5387e-6*0.3333e-8)*(step*(0:(n/u))/n);
	P = abs(Y/n);
	%subplot(2,2,3)
	hold on
	Z(1:1:n/u+1)=N;
	plot3(Z,t,P(1:n/u+1))
	axis([0,75,0,45e-12,0,1.5])
	grid on
end