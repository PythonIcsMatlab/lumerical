%programmed by R.Borumandi
x=0:.05:1;
m=120;
f=1-(5/m*pi)*cos(x);
plot(x,f);